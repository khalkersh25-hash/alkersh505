"use strict";

// ====== أدوات مساعدة ======
const $ = (s) => document.querySelector(s);
const byId = (id) => document.getElementById(id);
const ESC = (str) =>
  String(str).replace(
    /[&<>\"']/g,
    (m) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[
        m
      ])
  );

// عزل اتجاه الأرقام LTR داخل واجهة RTL
const LRI = "\u2066",
  PDI = "\u2069";
const wrapLTR = (s) => LRI + s + PDI;

// ====== إعدادات عامة ======
let BASE_CURRENCY = "USD"; // ثابت
let targetCurrency = "YER"; // الحساب الافتراضي

// تنسيق أرقام 0-9 LTR
function fmtNum(n, digits = 2) {
  if (!isFinite(n)) return wrapLTR("--");
  const s = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
    useGrouping: true
  }).format(n);
  return wrapLTR(s);
}
function fmtInt(n) {
  if (!isFinite(n)) return wrapLTR("--");
  const s = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 0,
    minimumFractionDigits: 0,
    useGrouping: true
  }).format(n);
  return wrapLTR(s);
}
function fmtMoney(n, cur) {
  if (!isFinite(n)) return wrapLTR("--");
  const s =
    new Intl.NumberFormat("en-US", {
      maximumFractionDigits: 2,
      minimumFractionDigits: 2,
      useGrouping: true
    }).format(n) +
    " " +
    cur;
  return wrapLTR(s);
}
function fmtPercent(n, digits = 2) {
  if (!isFinite(n)) return wrapLTR("--");
  const s =
    new Intl.NumberFormat("en-US", {
      maximumFractionDigits: digits,
      minimumFractionDigits: digits,
      useGrouping: true
    }).format(n) + "%";
  return wrapLTR(s);
}

// ====== نموذج بيانات الخامات (بالعملة الأساسية USD) ======
const DEFAULT_MATERIALS = [
  { name: "فلكس", price: 18 },
  { name: "بانر", price: 15 },
  { name: "ملصقات (فينيـل)", price: 25 },
  { name: "ورق لاصق", price: 12 },
  { name: "شبكي (مش)", price: 20 }
];

function loadState() {
  const m = localStorage.getItem("materialsV4");
  const rollWidth = localStorage.getItem("rollWidth") || "1.2";
  const rollLength = localStorage.getItem("rollLength") || "50";
  const manualRate = localStorage.getItem("manualRate") || "";
  const purchaseRollUSD = localStorage.getItem("purchaseRollUSD") || "";
  const usePurchasePrice = localStorage.getItem("usePurchasePrice") === "1";
  byId("rollWidth").value = rollWidth;
  byId("rollLength").value = rollLength;
  byId("manualRate").value = manualRate;
  byId("purchaseRollUSD").value = purchaseRollUSD;
  byId("usePurchasePrice").checked = usePurchasePrice;
  return m ? JSON.parse(m) : DEFAULT_MATERIALS;
}

function saveState() {
  localStorage.setItem("materialsV4", JSON.stringify(materials));
  localStorage.setItem("rollWidth", byId("rollWidth").value);
  localStorage.setItem("rollLength", byId("rollLength").value);
  localStorage.setItem("manualRate", byId("manualRate").value);
  localStorage.setItem("purchaseRollUSD", byId("purchaseRollUSD").value || "");
  localStorage.setItem(
    "usePurchasePrice",
    byId("usePurchasePrice").checked ? "1" : "0"
  );
}

function resetState() {
  if (!confirm("إرجاع الإعدادات الافتراضية؟")) return;
  localStorage.clear();
  materials = DEFAULT_MATERIALS.map((x) => ({ ...x }));
  renderAll();
}

let materials = loadState();

// ====== حساب سعر الصرف ======
function getRate() {
  const r = parseFloat(byId("manualRate").value);
  return isFinite(r) && r > 0 ? r : 1; // 1 USD = r YER
}

// ====== عرض الخامات والجداول ======
function renderMaterialOptions() {
  const sel = byId("material");
  sel.innerHTML = "";
  materials.forEach((m, i) => {
    const opt = document.createElement("option");
    opt.value = i;
    opt.textContent = `${m.name}`;
    sel.appendChild(opt);
  });
}

function renderMaterialsTable() {
  const tbody = $("#materialsTable tbody");
  tbody.innerHTML = "";
  materials.forEach((m, i) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${m.name}</td>
      <td><input type="number" step="0.01" value="${m.price}" data-idx="${i}" class="priceInput" style="width:140px;background:transparent;border:1px solid var(--border);color:var(--text);border-radius:8px;padding:6px"></td>
      <td>
        <button class="btn ghost" data-rename="${i}">✏️ إعادة تسمية</button>
        <button class="btn ghost" data-del="${i}">🗑️ حذف</button>
      </td>`;
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll(".priceInput").forEach((inp) => {
    inp.addEventListener("input", (e) => {
      const idx = +e.target.getAttribute("data-idx");
      materials[idx].price = parseFloat(e.target.value) || 0;
    });
  });
  tbody.querySelectorAll("button[data-rename]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const idx = +btn.getAttribute("data-rename");
      const newName = prompt("اسم الخامة:", materials[idx].name);
      if (newName) {
        materials[idx].name = newName;
        renderMaterialOptions();
        renderMaterialsTable();
      }
    });
  });
  tbody.querySelectorAll("button[data-del]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const idx = +btn.getAttribute("data-del");
      if (confirm("حذف هذه الخامة؟")) {
        materials.splice(idx, 1);
        renderMaterialOptions();
        renderMaterialsTable();
      }
    });
  });
}

// ====== تسعير ======
function pricePerSqUSD(material) {
  return material.price || 0;
}
function derivePriceFromPurchase(purchaseUSD, rollWidthM, rollLengthM) {
  if (!(purchaseUSD > 0 && rollWidthM > 0 && rollLengthM > 0)) return null;
  const area = rollWidthM * rollLengthM; // m²
  return purchaseUSD / area; // USD per m²
}

// ====== الحساب ======
let lastReport = null;

function calc() {
  const mat = materials[+byId("material").value] || materials[0];
  const R = parseFloat(byId("rollWidth").value); // m
  const L = parseFloat(byId("rollLength").value); // m
  const W = parseFloat(byId("designWidth").value); // m
  const H = parseFloat(byId("designHeight").value); // m
  const Q = parseInt(byId("quantity").value) || 0;
  const marginPct = parseFloat(byId("marginPct").value) || 0;
  const rate = getRate();

  if (!(R > 0 && L > 0 && W > 0 && H > 0 && Q > 0)) {
    alert("رجاءً أدخل قيماً صحيحة لكل الحقول.");
    return;
  }

  // Paneling
  const panelsA = Math.ceil(W / R),
    panelLenA = H,
    lengthUsedA = panelsA * panelLenA * Q,
    areaUsedA = panelsA * R * H * Q,
    areaDesign = W * H * Q,
    wasteA = Math.max(areaUsedA - areaDesign, 0);
  const panelsB = Math.ceil(H / R),
    panelLenB = W,
    lengthUsedB = panelsB * panelLenB * Q,
    areaUsedB = panelsB * R * W * Q,
    wasteB = Math.max(areaUsedB - areaDesign, 0);
  let orientation, panels, lengthUsed, areaUsed, waste;
  if (wasteA < wasteB || (wasteA === wasteB && lengthUsedA <= lengthUsedB)) {
    orientation = "بدون تدوير (العرض ← رول)";
    panels = panelsA;
    lengthUsed = lengthUsedA;
    areaUsed = areaUsedA;
    waste = wasteA;
  } else {
    orientation = "تدوير 90° (الطول ← رول)";
    panels = panelsB;
    lengthUsed = lengthUsedB;
    areaUsed = areaUsedB;
    waste = wasteB;
  }
  const rollsNeeded = Math.ceil(lengthUsed / L);

  // Pricing
  let priceUSD = pricePerSqUSD(mat); // USD/m² (سعر ثابت للخام)
  const purchaseUSD = parseFloat(byId("purchaseRollUSD").value);
  const usePurchase = byId("usePurchasePrice").checked && purchaseUSD > 0;
  const derived = derivePriceFromPurchase(purchaseUSD, R, L);
  if (usePurchase && derived) {
    priceUSD = derived;
  }
  const priceYER = priceUSD * rate; // YER/m²
  const costRawYER = priceYER * areaDesign; // YER
  const profitYER = costRawYER * (marginPct / 100);
  const costFinalYER = costRawYER + profitYER;
  const wastePct = areaUsed > 0 ? (waste / areaUsed) * 100 : 0;

  byId("areaEach").textContent = fmtNum(W * H) + " م²";
  byId("areaTotal").textContent = fmtNum(areaDesign) + " م²";
  byId("pricePerSq").innerHTML =
    fmtMoney(priceYER, "YER") +
    (usePurchase
      ? ' <span class="pill">(من سعر الشراء)</span>'
      : ' <span class="pill">(سعر الخام الثابت)</span>') +
    " — أساس: " +
    fmtMoney(priceUSD, "USD") +
    " عند سعر " +
    fmtNum(rate, 4) +
    " YER";
  byId("costRaw").textContent = fmtMoney(costRawYER, "YER");
  byId("profit").textContent = fmtMoney(profitYER, "YER");
  byId("costFinal").textContent = fmtMoney(costFinalYER, "YER");
  byId("orientation").textContent = orientation;
  byId("panels").innerHTML = fmtInt(panels) + " شريحة/قطعة";
  byId("rollUsed").innerHTML = fmtNum(lengthUsed) + " م";
  byId("rollsNeeded").innerHTML =
    fmtInt(rollsNeeded) + " رول (طول " + fmtInt(L) + "م)";
  byId("wastePct").innerHTML =
    fmtPercent(wastePct) +
    " " +
    (wastePct > 0
      ? `<span class="warn">(هدر: ${fmtNum(waste)} م²)</span>`
      : '<span class="ok">(لا هدر)</span>');

  lastReport = {
    material: mat.name,
    priceUSD,
    priceYER,
    rate,
    rollWidth: R,
    rollLength: L,
    designWidth: W,
    designHeight: H,
    quantity: Q,
    orientation,
    panels,
    areaEach: W * H,
    areaTotal: areaDesign,
    areaUsed,
    waste,
    wastePct,
    lengthUsed,
    rollsNeeded,
    marginPct,
    costRawYER,
    profitYER,
    costFinalYER,
    clientName: byId("clientName").value || "",
    notes: byId("notes").value || "",
    pricedFrom: usePurchase ? "purchase" : "fixed",
    purchaseRollUSD: purchaseUSD
  };
}

// ====== CSV ======
function buildCSV(rows) {
  return rows
    .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
    .join("\n");
}
function exportCSV() {
  if (!lastReport) {
    alert("قم بالحساب أولاً.");
    return;
  }
  const r = lastReport;
  const rows = [
    ["الخامة", r.material],
    [
      "تم الاعتماد على",
      r.pricedFrom === "purchase" ? "سعر الشراء" : "السعر الثابت"
    ],
    ["سعر شراء الرول (USD)", r.purchaseRollUSD || ""],
    ["سعر/م² USD", r.priceUSD],
    ["سعر/م² YER", r.priceYER],
    ["سعر الصرف (1 USD = ? YER)", r.rate],
    ["عرض الرول (م)", r.rollWidth],
    ["طول الرول (م)", r.rollLength],
    ["عرض التصميم (م)", r.designWidth],
    ["طول التصميم (م)", r.designHeight],
    ["الكمية", r.quantity],
    ["الاتجاه", r.orientation],
    ["عدد الشرائح/قطعة", r.panels],
    ["مساحة القطعة (م²)", r.areaEach],
    ["المساحة الإجمالية (م²)", r.areaTotal],
    ["المساحة المستعملة (م²)", r.areaUsed],
    ["الهدر (م²)", r.waste],
    ["نسبة الهدر %", r.wastePct],
    ["طول الرول المستخدم (م)", r.lengthUsed],
    ["عدد الرولات", r.rollsNeeded],
    ["هامش الربح %", r.marginPct],
    ["التكلفة قبل الربح (YER)", r.costRawYER],
    ["الربح (YER)", r.profitYER],
    ["التكلفة النهائية (YER)", r.costFinalYER]
  ];
  const csv = buildCSV(rows);
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "print-cost-report.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

// ====== فاتورة PDF (YER / USD) ======
function buildInvoiceHTML(r, currency) {
  // NB: قالب نظيف لتفادي محارف خفية في WebView
  const css =
    "body{font-family:Arial,Helvetica,sans-serif;padding:24px;color:#111;background:#fff} h1{margin:0 0 8px} h2{margin:16px 0 8px} table{width:100%;border-collapse:collapse} th,td{border:1px solid #ddd;padding:8px;text-align:right} .muted{color:#666} .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px} .tot{font-weight:bold}";
  const pricePerSq = currency === "USD" ? r.priceUSD : r.priceYER;
  const unitCur = currency === "USD" ? "USD" : "YER";
  const costRaw = currency === "USD" ? r.costRawYER / r.rate : r.costRawYER;
  const profit = currency === "USD" ? r.profitYER / r.rate : r.profitYER;
  const costFinal =
    currency === "USD" ? r.costFinalYER / r.rate : r.costFinalYER;
  const dateStr = wrapLTR(new Date().toLocaleDateString("en-GB"));

  return (
    '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>فاتورة طباعة</title><style>' +
    css +
    "</style></head><body>" +
    "<h1>فاتورة طباعة</h1>" +
    '<div class="grid"><div><b>العميل:</b> ' +
    ESC(r.clientName || "—") +
    '</div><div class="muted">تاريخ: ' +
    dateStr +
    "</div></div>" +
    "<h2>التفاصيل</h2>" +
    "<table><tr><th>الخامة</th><th>الأبعاد (م)</th><th>الكمية</th><th>سعر/م²</th><th>المساحة الإجمالية</th><th>المجموع</th></tr>" +
    "<tr><td>" +
    ESC(r.material) +
    "</td><td>" +
    fmtNum(r.designWidth) +
    " × " +
    fmtNum(r.designHeight) +
    "</td><td>" +
    fmtInt(r.quantity) +
    "</td><td>" +
    fmtMoney(pricePerSq, unitCur) +
    "</td><td>" +
    fmtNum(r.areaTotal) +
    " م²</td><td>" +
    fmtMoney(costRaw, unitCur) +
    "</td></tr></table>" +
    '<p class="muted">سعر الصرف المُستخدم: ' +
    wrapLTR(
      "1 USD = " +
        new Intl.NumberFormat("en-US", { maximumFractionDigits: 4 }).format(
          r.rate
        ) +
        " YER"
    ) +
    "</p>" +
    "<h2>الملخص</h2>" +
    "<table><tr><td>الربح (" +
    fmtPercent(r.marginPct, 1) +
    ')</td><td class="tot">' +
    fmtMoney(profit, unitCur) +
    '</td></tr><tr><td>الإجمالي المستحق</td><td class="tot">' +
    fmtMoney(costFinal, unitCur) +
    "</td></tr></table>" +
    (r.notes ? "<p><b>ملاحظات:</b> " + ESC(r.notes) + "</p>" : "") +
    '<p class="muted">المصدر السعري: ' +
    (r.pricedFrom === "purchase" ? "سعر الشراء" : "السعر الثابت") +
    " — اتجاه القص: " +
    ESC(r.orientation) +
    " — شرائح/قطعة: " +
    fmtInt(r.panels) +
    " — رولات متوقعة: " +
    fmtInt(r.rollsNeeded) +
    "</p>" +
    "</body></html>"
  );
}

function openInvoice(currency) {
  if (!lastReport) {
    alert("قم بالحساب أولاً.");
    return;
  }
  const html = buildInvoiceHTML(lastReport, currency);

  // ملاحظة (Android WebView): window.open قد لا يعمل، لذا نستخدم Blob + iframe للطباعة
  try {
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const iframe = document.createElement("iframe");
    iframe.style.position = "fixed";
    iframe.style.left = "-9999px";
    iframe.src = url;
    document.body.appendChild(iframe);
    iframe.onload = () => {
      try {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();
      } catch (_) {}
    };
  } catch (e) {
    // رجوع للخطة القديمة إذا لم تتوفر Blob
    const win = window.open("", "_blank");
    if (!win) {
      alert("يرجى السماح بالنوافذ المنبثقة.");
      return;
    }
    win.document.open();
    win.document.write(String(html));
    win.document.close();
    setTimeout(() => {
      try {
        win.focus();
        win.print();
      } catch (_) {}
    }, 150);
  }
}

// ====== طباعة الصفحة الحالية ======
function printPage() {
  window.print();
}

// ====== الاختبارات ======
function logTest(msg) {
  const el = byId("testLog");
  el.textContent += (el.textContent === "—" ? "" : "\n") + msg;
}
function clearTests() {
  byId("testLog").textContent = "";
}
function runTests() {
  clearTests();
  try {
    // 1) تنسيق الأرقام 0-9 (بدون ٠-٩/۰-۹)
    const s1 = fmtNum(1234.56);
    if (/[٠-٩۰-۹]/.test(s1)) throw new Error("الأرقام ليست 0-9");
    if (!/[0-9]/.test(s1)) throw new Error("لم يتم استخدام أرقام 0-9");
    logTest("تنسيق أرقام LTR 0-9: ✅ " + s1);

    // 2) اشتقاق سعر المتر من سعر الشراء
    const d = derivePriceFromPurchase(500, 1, 50); // 500 USD لرول 1م × 50م => 10 USD/m²
    if (Math.abs(d - 10) > 1e-9)
      throw new Error("اشتقاق سعر المتر من سعر الشراء غير صحيح");
    logTest("اشتقاق سعر المتر من سعر الشراء: ✅");

    // 3) منطق الاتجاه
    (function () {
      const R = 1.5,
        W = 2,
        H = 1,
        Q = 1;
      const panelsA = Math.ceil(W / R),
        panelLenA = H,
        lengthUsedA = panelsA * panelLenA * Q,
        areaUsedA = panelsA * R * H * Q,
        areaDesign = W * H * Q,
        wasteA = Math.max(areaUsedA - areaDesign, 0);
      const panelsB = Math.ceil(H / R),
        panelLenB = W,
        lengthUsedB = panelsB * panelLenB * Q,
        areaUsedB = panelsB * R * W * Q,
        wasteB = Math.max(areaUsedB - areaDesign, 0);
      const chosen =
        wasteA < wasteB || (wasteA === wasteB && lengthUsedA <= lengthUsedB)
          ? "A"
          : "B";
      if (chosen !== "A") throw new Error("الاختيار فشل");
    })();
    logTest("اختيار الاتجاه: ✅");

    // 4) فحص CSV (سطر جديد \n)
    const csv = buildCSV([
      ["a", "b"],
      ["1", "2"]
    ]);
    if (csv.indexOf("\n") === -1 || csv.split("\n").length !== 2)
      throw new Error("CSV لا يحتوي على سطر جديد صحيح");
    logTest("بناء CSV: ✅");

    // 5) فحص قوالب الفاتورة
    const dummy = {
      material: "بانر",
      designWidth: 1,
      designHeight: 2,
      quantity: 3,
      priceUSD: 10,
      priceYER: 2500,
      rate: 250,
      areaTotal: 6,
      marginPct: 10,
      costRawYER: 15000,
      profitYER: 1500,
      costFinalYER: 16500,
      orientation: "بدون تدوير",
      panels: 2,
      rollsNeeded: 1,
      clientName: "شركة",
      notes: "اختبار",
      pricedFrom: "fixed"
    };
    const invYer = buildInvoiceHTML(dummy, "YER");
    const invUsd = buildInvoiceHTML(dummy, "USD");
    if (!(invYer.includes("<html") && invUsd.includes("<html")))
      throw new Error("قالب الفاتورة غير مُنشأ بشكل صحيح");
    if (!invYer.includes("\u2066") || !invUsd.includes("\u2066"))
      throw new Error("أرقام الفاتورة ليست معزولة LTR");
    logTest("قالب الفاتورة: ✅");

    logTest("\nجميع الاختبارات مرّت بنجاح ✅");
  } catch (err) {
    logTest("❌ فشل اختبار: " + err.message);
  }
}

// ====== أحداث عامة ======
function renderAll() {
  renderMaterialOptions();
  renderMaterialsTable();
}

byId("calc").addEventListener("click", () => {
  calc();
});
byId("addMaterial").addEventListener("click", () => {
  const name = prompt("اسم الخامة الجديدة:");
  if (!name) return;
  const price = parseFloat(prompt("السعر الثابت للمتر (USD):", "0")) || 0;
  materials.push({ name, price });
  renderAll();
});
byId("saveSettings").addEventListener("click", () => {
  saveState();
  alert("تم الحفظ");
});
byId("resetSettings").addEventListener("click", resetState);
byId("exportCSV").addEventListener("click", exportCSV);
byId("print").addEventListener("click", printPage);
byId("openInvoiceYER").addEventListener("click", () => openInvoice("YER"));
byId("openInvoiceUSD").addEventListener("click", () => openInvoice("USD"));
byId("runTests").addEventListener("click", runTests);
byId("runTests2").addEventListener("click", runTests);

// بداية
renderAll();
